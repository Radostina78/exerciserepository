package exercise.library;

public class BookNotFoundException extends Exception
{
}
